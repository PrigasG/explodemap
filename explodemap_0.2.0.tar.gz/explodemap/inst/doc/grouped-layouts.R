## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>",
  fig.width = 7,
  fig.height = 5
)

## ----setup--------------------------------------------------------------------
library(sf)
library(explodemap)

## ----synthetic-grouped--------------------------------------------------------
sq <- function(xmin, ymin, size = 1000) {
  st_polygon(list(matrix(
    c(xmin, ymin,
      xmin + size, ymin,
      xmin + size, ymin + size,
      xmin, ymin + size,
      xmin, ymin),
    ncol = 2,
    byrow = TRUE
  )))
}

geom <- st_sfc(
  sq(0, 0), sq(3000, 0),       # R1
  sq(9000, 0), sq(12000, 0),   # R2
  sq(24000, 0), sq(27000, 0),  # R3
  crs = 3857
)

x <- st_sf(
  id     = paste0("u", 1:6),
  region = c("R1", "R1", "R2", "R2", "R3", "R3"),
  geometry = geom
)

## ----auto-mode----------------------------------------------------------------
g_auto <- explode_grouped(
  x,
  region_col = "region",
  mode       = "auto",
  plot       = FALSE,
  quiet      = TRUE
)

class(g_auto)
print(g_auto)

## ----auto-names---------------------------------------------------------------
names(g_auto)

## ----auto-plot----------------------------------------------------------------
plot(g_auto)

## ----collision-mode-----------------------------------------------------------
g_collide <- explode_grouped(
  x,
  region_col = "region",
  mode       = "auto_collision",
  plot       = FALSE,
  quiet      = TRUE
)

plot(g_collide)

## ----convergence--------------------------------------------------------------
g_collide$anchors[, c("region", "block_radius", "anchor_x", "anchor_y")]

## ----all-views, fig.width = 10, fig.height = 4--------------------------------
plot(g_collide, "all")

## ----layout-regions-----------------------------------------------------------
anchors <- layout_regions(
  x,
  region_col = "region",
  mode       = "auto",
  quiet      = TRUE
)

anchors[, c("region", "block_radius", "n_units", "anchor_x", "anchor_y")]

## ----manual-anchors-----------------------------------------------------------
manual_anchors <- anchors
manual_anchors$anchor_x <- manual_anchors$anchor_x + c(0, 500, 1000)
manual_anchors$anchor_y <- manual_anchors$anchor_y + c(0, 250, 500)

g_manual <- explode_grouped(
  x,
  region_col = "region",
  mode       = "manual",
  anchors    = manual_anchors,
  plot       = FALSE,
  quiet      = TRUE
)

plot(g_manual)

## ----summary------------------------------------------------------------------
summary(g_collide)

## ----grouped-focus-map, eval=FALSE--------------------------------------------
# focus_map(
#   g_collide,
#   label_col = "id",
#   id_col = "id",
#   group_col = "region",
#   info_cols = c("region"),
#   performance_mode = TRUE
# )

