## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>",
  fig.width = 7,
  fig.height = 5
)

## ----setup--------------------------------------------------------------------
library(sf)
library(explodemap)

## ----synthetic-data-----------------------------------------------------------
sq <- function(xmin, ymin, size = 1000) {
  st_polygon(list(matrix(
    c(xmin, ymin,
      xmin + size, ymin,
      xmin + size, ymin + size,
      xmin, ymin + size,
      xmin, ymin),
    ncol = 2,
    byrow = TRUE
  )))
}

geom <- st_sfc(
  sq(0, 0), sq(3000, 0),       # Region A
  sq(12000, 0), sq(15000, 0),  # Region B
  crs = 3857
)

x <- st_sf(
  id     = c("a1", "a2", "b1", "b2"),
  region = c("A", "A", "B", "B"),
  geometry = geom
)

x

## ----explode-basic------------------------------------------------------------
result <- explode_sf(x, region_col = "region", plot = FALSE)

## ----explode-quiet------------------------------------------------------------
quiet_result <- explode_sf(x, region_col = "region", plot = FALSE, quiet = TRUE)
class(quiet_result)

## ----class-check--------------------------------------------------------------
class(result)
names(result)

## ----print--------------------------------------------------------------------
print(result)

## ----summary------------------------------------------------------------------
summary(result)

## ----plot-exploded------------------------------------------------------------
plot(result)

## ----plot-both, fig.width = 10------------------------------------------------
plot(result, "both")

## ----calibration--------------------------------------------------------------
calibration_row(result)

## ----manual-------------------------------------------------------------------
manual <- explode_sf(
  x,
  region_col = "region",
  alpha_r = 100,
  alpha_l = 200,
  plot = FALSE
)

manual$params

## ----partial-manual-----------------------------------------------------------
more_region_gap <- explode_sf(
  x,
  region_col = "region",
  alpha_r = result$params$alpha_r * 1.5,
  plot = FALSE
)

more_region_gap$params

## ----refine-example, eval=FALSE-----------------------------------------------
# refined <- explode_sf(
#   x,
#   region_col = "region",
#   refine = TRUE,
#   refine_min_gap = 0.15,
#   refine_max_shift = 0.10,
#   plot = FALSE
# )
# 
# refined$refinement

## ----refine, echo=FALSE-------------------------------------------------------
has_refinement <- "refine" %in% names(formals(explode_sf))

if (has_refinement) {
  refined <- explode_sf(
    x,
    region_col = "region",
    refine = TRUE,
    refine_min_gap = 0.15,
    refine_max_shift = 0.10,
    plot = FALSE
  )

  refined$refinement
} else {
  message("This installed explodemap build does not include refinement yet.")
}

## ----centroid-mode------------------------------------------------------------
pos <- explode_sf(
  x,
  region_col = "region",
  centroid_fun = "point_on_surface",
  plot = FALSE
)

## ----tiger-example, eval = FALSE----------------------------------------------
# nj <- explode_state(
#   state_fips = "34", crs = 32118,
#   region_map = list(
#     North   = c("Bergen", "Essex", "Hudson", "Morris",
#                 "Passaic", "Sussex", "Union", "Warren"),
#     Central = c("Hunterdon", "Mercer", "Middlesex",
#                 "Monmouth", "Somerset"),
#     South   = c("Atlantic", "Burlington", "Camden", "Cape May",
#                 "Cumberland", "Gloucester", "Ocean", "Salem")
#   ),
#   label = "New Jersey"
# )

## ----lookup-example, eval = FALSE---------------------------------------------
# groups <- read.csv("region_assignments.csv")
# 
# result <- explode_sf_with_lookup(
#   my_sf,
#   join_col   = "GEOID",
#   lookup     = groups,
#   lookup_key = "geoid",
#   region_col = "region"
# )

## ----export-example, eval = FALSE---------------------------------------------
# result <- explode_sf(
#   my_sf,
#   region_col = "region",
#   export = "output.geojson"
# )

## ----focus-map, eval=FALSE----------------------------------------------------
# focus_map(
#   result,
#   label_col = "id",
#   id_col = "id",
#   group_col = "region",
#   group_palette = c(A = "#4C78A8", B = "#F58518", C = "#54A24B"),
#   info_cols = c("id", "region"),
#   info_card_scale = 0.95
# )

## ----shiny-focus-map, eval=FALSE----------------------------------------------
# ui <- shiny::fluidPage(
#   focusmapOutput("map", height = "650px"),
#   shiny::verbatimTextOutput("selected")
# )
# 
# server <- function(input, output, session) {
#   exploded <- explode_sf(x, "region", plot = FALSE, quiet = TRUE)
# 
#   output$map <- renderFocusmap({
#     focus_map(
#       exploded,
#       label_col = "id",
#       id_col = "id",
#       group_col = "region",
#       group_palette = c(A = "#4C78A8", B = "#F58518", C = "#54A24B")
#     )
#   })
# 
#   output$selected <- shiny::renderPrint(input$map_selected)
# }

## ----section-focus-map, eval=FALSE--------------------------------------------
# focused <- explode_section(
#   x,
#   section_col = "region",
#   section = "A",
#   region_col = "county",
#   alpha_r = 900,
#   alpha_l = 600,
#   plot = FALSE,
#   quiet = TRUE
# )
# 
# focus_map(
#   focused,
#   label_col = "id",
#   context_col = ".explodemap_role",
#   context_mode = "fade"
# )

## ----tiny-feature-focus, eval=FALSE-------------------------------------------
# focus_map(
#   focused,
#   label_col = "id",
#   context_col = ".explodemap_role",
#   context_mode = "fade",
#   min_focus_width = 115,
#   min_focus_height = 88,
#   tiny_feature_threshold = 52,
#   tiny_feature_boost = 1.45,
#   origin_context = "inset",
#   origin_context_position = "bottom-left",
#   focus_context_opacity = 0.14,
#   show_drag_zoom = TRUE
# )

