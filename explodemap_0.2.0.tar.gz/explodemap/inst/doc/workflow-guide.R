## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>",
  fig.width = 7,
  fig.height = 5
)

## ----eval=FALSE---------------------------------------------------------------
# result <- explode_sf(
#   my_sf,
#   region_col = "region",
#   plot = FALSE,
#   quiet = TRUE
# )

## ----eval=FALSE---------------------------------------------------------------
# result <- explode_sf_with_lookup(
#   my_sf,
#   join_col = "GEOID",
#   lookup = region_lookup,
#   lookup_key = "geoid",
#   region_col = "region",
#   plot = FALSE,
#   quiet = TRUE
# )

## ----eval=FALSE---------------------------------------------------------------
# result <- explode_state(
#   state_fips = "34",
#   crs = 32118,
#   region_map = nj_regions,
#   plot = FALSE,
#   quiet = TRUE
# )

## ----eval=FALSE---------------------------------------------------------------
# result <- explode_sf(
#   my_sf,
#   region_col = "region",
#   refine = TRUE,
#   refine_min_gap = 250,
#   refine_max_shift = 150,
#   plot = FALSE
# )

## ----eval=FALSE---------------------------------------------------------------
# grouped <- explode_grouped(
#   my_sf,
#   region_col = "hhs_region",
#   mode = "auto_collision",
#   plot = FALSE,
#   quiet = TRUE
# )

## ----eval=FALSE---------------------------------------------------------------
# focus_map(
#   result,
#   group_col = "region",
#   group_palette = c(North = "#4C78A8", Central = "#F58518", South = "#54A24B"),
#   info_cols = c("NAME", "GEOID"),
#   focus_size = 0.76,
#   focus_padding = 40,
#   lift_scale = 1.16,
#   info_card_scale = 1.2
# )

## ----eval=FALSE---------------------------------------------------------------
# ui <- fluidPage(
#   focusmapOutput("map", height = "700px")
# )
# 
# server <- function(input, output, session) {
#   result <- explode_sf(munis, "region", plot = FALSE, quiet = TRUE)
# 
#   output$map <- renderFocusmap({
#     focus_map(
#       result,
#       label_col = "NAME",
#       id_col = "GEOID",
#       group_col = "region",
#       group_palette = c(North = "#4C78A8", Central = "#F58518", South = "#54A24B"),
#       info_cols = c("GEOID", "population")
#     )
#   })
# }

## ----eval=FALSE---------------------------------------------------------------
# focused <- explode_section(
#   munis,
#   section_col = "nj_region",
#   section = input$region,
#   region_col = "county_name",
#   alpha_r = 900,
#   alpha_l = 600,
#   plot = FALSE,
#   quiet = TRUE
# )
# 
# focus_map(
#   focused,
#   label_col = "NAME",
#   id_col = "GEOID",
#   context_col = ".explodemap_role",
#   context_mode = "fade",
#   context_opacity = 0.16,
#   performance_mode = TRUE
# )

## ----eval=FALSE---------------------------------------------------------------
# source(system.file("examples/basic_explode_sf.R", package = "explodemap"))
# source(system.file("examples/collision_refinement.R", package = "explodemap"))
# source(system.file("examples/lookup_workflow.R", package = "explodemap"))
# source(system.file("examples/manual_parameter_tuning.R", package = "explodemap"))

## ----eval=FALSE---------------------------------------------------------------
# if (interactive()) {
#   shiny::runApp(system.file("examples/focusmap_munis_app.R", package = "explodemap"))
#   shiny::runApp(system.file("examples/focusmap_counties_app.R", package = "explodemap"))
# }

